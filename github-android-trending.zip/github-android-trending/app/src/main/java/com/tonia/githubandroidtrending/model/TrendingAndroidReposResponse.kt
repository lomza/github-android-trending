package com.tonia.githubandroidtrending.model

class TrendingAndroidReposResponse {
}
