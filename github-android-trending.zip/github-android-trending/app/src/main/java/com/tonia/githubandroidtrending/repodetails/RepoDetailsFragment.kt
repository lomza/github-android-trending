package com.tonia.githubandroidtrending.repodetails

class RepoDetailsFragment {
}